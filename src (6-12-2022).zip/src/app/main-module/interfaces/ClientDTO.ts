export interface ClientDTO {
    id:             number;
    name:           string;
    billingAddress: string;
    email:          string;
    phone:          string;
    hash:           string;
}