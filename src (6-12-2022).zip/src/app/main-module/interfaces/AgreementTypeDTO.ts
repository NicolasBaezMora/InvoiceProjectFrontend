
export interface AgreementTypeDTO {
    id:     number;
    method: string;
}