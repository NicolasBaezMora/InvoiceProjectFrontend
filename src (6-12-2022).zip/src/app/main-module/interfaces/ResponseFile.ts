export interface ResponseFile {
    consistent: number;
    inconsistent: number;
}