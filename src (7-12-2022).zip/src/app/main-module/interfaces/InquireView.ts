export interface InquireView {
    imgUrl: string;
    textCard: string;
    inquireType: string;
  }