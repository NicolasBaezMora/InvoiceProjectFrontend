export interface StateDialog {
    inquireType: string;
    display: boolean;
}