import { Component } from '@angular/core';

@Component({
  selector: 'app-my-custom-spinner',
  templateUrl: './my-custom-spinner.component.html',
  styleUrls: ['./my-custom-spinner.component.scss']
})
export class MyCustomSpinnerComponent {

}
